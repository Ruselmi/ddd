/**
 * Taniku - Map Module
 * Leaflet.js with OpenStreetMap for price visualization
 */

const MapModule = {
    map: null,
    markers: [],
    selectedCommodity: null,

    // Indonesia province coordinates
    provinces: [
        { name: 'Aceh', lat: 4.695135, lng: 96.7494 },
        { name: 'Sumatera Utara', lat: 2.1154, lng: 99.5451 },
        { name: 'Sumatera Barat', lat: -0.7399, lng: 100.8 },
        { name: 'Riau', lat: 0.2933, lng: 101.7068 },
        { name: 'Jambi', lat: -1.4852, lng: 102.438 },
        { name: 'Sumatera Selatan', lat: -3.3194, lng: 103.9144 },
        { name: 'Bengkulu', lat: -3.5778, lng: 102.3464 },
        { name: 'Lampung', lat: -4.5586, lng: 105.4068 },
        { name: 'Kepulauan Bangka Belitung', lat: -2.7411, lng: 106.4406 },
        { name: 'Kepulauan Riau', lat: 3.9457, lng: 108.1429 },
        { name: 'DKI Jakarta', lat: -6.2088, lng: 106.8456 },
        { name: 'Jawa Barat', lat: -6.9175, lng: 107.6191 },
        { name: 'Jawa Tengah', lat: -7.1509, lng: 110.1403 },
        { name: 'DI Yogyakarta', lat: -7.7956, lng: 110.3695 },
        { name: 'Jawa Timur', lat: -7.2504, lng: 112.7688 },
        { name: 'Banten', lat: -6.4058, lng: 106.0641 },
        { name: 'Bali', lat: -8.3405, lng: 115.092 },
        { name: 'Nusa Tenggara Barat', lat: -8.6529, lng: 117.3616 },
        { name: 'Nusa Tenggara Timur', lat: -8.6574, lng: 121.0794 },
        { name: 'Kalimantan Barat', lat: -0.2788, lng: 111.4754 },
        { name: 'Kalimantan Tengah', lat: -1.6815, lng: 113.3824 },
        { name: 'Kalimantan Selatan', lat: -3.0926, lng: 115.2838 },
        { name: 'Kalimantan Timur', lat: 1.6407, lng: 116.4194 },
        { name: 'Kalimantan Utara', lat: 3.0731, lng: 116.0414 },
        { name: 'Sulawesi Utara', lat: 0.6247, lng: 123.9751 },
        { name: 'Sulawesi Tengah', lat: -1.4301, lng: 121.4456 },
        { name: 'Sulawesi Selatan', lat: -3.6688, lng: 119.9741 },
        { name: 'Sulawesi Tenggara', lat: -4.1449, lng: 122.175 },
        { name: 'Gorontalo', lat: 0.6999, lng: 122.4467 },
        { name: 'Sulawesi Barat', lat: -2.8441, lng: 119.2321 },
        { name: 'Maluku', lat: -3.2385, lng: 130.1453 },
        { name: 'Maluku Utara', lat: 1.5709, lng: 127.8088 },
        { name: 'Papua Barat', lat: -1.3361, lng: 133.1747 },
        { name: 'Papua', lat: -4.2699, lng: 138.0804 }
    ],

    init() {
        const container = document.getElementById('map-container');
        if (!container || this.map) return;

        this.map = L.map('map-container').setView([-2.5, 118], 5);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors',
            maxZoom: 18
        }).addTo(this.map);

        this.addProvinceMarkers();
        this.setupCommoditySelect();
    },

    addProvinceMarkers() {
        this.provinces.forEach(province => {
            const price = this.getRandomPrice();
            const color = Utils.getPriceColor(price, 10000, 25000);

            const marker = L.circleMarker([province.lat, province.lng], {
                radius: 12,
                fillColor: color,
                color: '#fff',
                weight: 2,
                opacity: 1,
                fillOpacity: 0.8
            }).addTo(this.map);

            marker.bindPopup(this.createPopupContent(province, price));
            marker.on('click', () => this.onMarkerClick(province, marker));

            this.markers.push({ marker, province, price });
        });
    },

    createPopupContent(province, price) {
        const commodity = this.selectedCommodity || { name: 'Beras', icon: '🌾' };
        const change = (Math.random() * 10 - 5).toFixed(2);
        const changeClass = parseFloat(change) >= 0 ? 'up' : 'down';
        const changeSign = parseFloat(change) >= 0 ? '+' : '';

        return `
            <div class="map-popup">
                <h4>${province.name}</h4>
                <div style="display:flex;align-items:center;gap:8px;margin:8px 0;">
                    <span style="font-size:24px">${commodity.icon}</span>
                    <span>${commodity.name}</span>
                </div>
                <div style="font-size:20px;font-weight:bold;color:#22c55e;">
                    ${Utils.formatCurrency(price)}
                </div>
                <div style="color:${changeClass === 'up' ? '#22c55e' : '#ef4444'}">
                    ${changeSign}${change}%
                </div>
            </div>
        `;
    },

    setupCommoditySelect() {
        const select = document.getElementById('map-commodity-select');
        if (!select) return;

        Commodities.getAll().forEach(c => {
            const option = document.createElement('option');
            option.value = c.id;
            option.textContent = `${c.icon} ${c.name}`;
            select.appendChild(option);
        });

        select.addEventListener('change', (e) => {
            this.selectedCommodity = Commodities.getById(e.target.value);
            this.updateMarkers();
        });
    },

    updateMarkers() {
        this.markers.forEach(({ marker, province }) => {
            const price = this.getRandomPrice();
            const color = Utils.getPriceColor(price, 10000, 25000);
            marker.setStyle({ fillColor: color });
            marker.setPopupContent(this.createPopupContent(province, price));
        });
    },

    onMarkerClick(province, marker) {
        this.map.setView([province.lat, province.lng], 8, { animate: true });
    },

    getRandomPrice() {
        return Math.floor(Math.random() * 15000) + 10000;
    },

    resize() {
        if (this.map) {
            this.map.invalidateSize();
        }
    }
};
