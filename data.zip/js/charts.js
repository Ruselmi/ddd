/**
 * Taniku - Charts Module
 * Chart.js visualizations for price trends
 */

const Charts = {
    weeklyChart: null,
    categoryChart: null,
    modalChart: null,

    colors: {
        primary: '#22c55e',
        secondary: '#3b82f6',
        accent: '#f59e0b',
        danger: '#ef4444',
        gridColor: 'rgba(255,255,255,0.1)'
    },

    init() {
        Chart.defaults.color = '#8b949e';
        Chart.defaults.borderColor = this.colors.gridColor;
    },

    async renderWeeklyChart() {
        const ctx = document.getElementById('weekly-chart');
        if (!ctx) return;

        const labels = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
        const data = this.generateRandomData(7, 10000, 20000);

        if (this.weeklyChart) this.weeklyChart.destroy();

        this.weeklyChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'Rata-rata Harga',
                    data,
                    borderColor: this.colors.primary,
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    fill: true,
                    tension: 0.4,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        grid: { color: this.colors.gridColor }
                    },
                    x: {
                        grid: { display: false }
                    }
                }
            }
        });
    },

    async renderCategoryChart() {
        const ctx = document.getElementById('category-chart');
        if (!ctx) return;

        const categories = Commodities.categories;
        const data = categories.map(() => Math.floor(Math.random() * 10) + 5);

        if (this.categoryChart) this.categoryChart.destroy();

        this.categoryChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: categories,
                datasets: [{
                    data,
                    backgroundColor: [
                        this.colors.primary,
                        this.colors.secondary,
                        this.colors.accent,
                        this.colors.danger,
                        '#8b5cf6',
                        '#06b6d4'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'right' }
                }
            }
        });
    },

    renderModalChart(commodity) {
        const ctx = document.getElementById('modal-chart');
        if (!ctx) return;

        const labels = Array.from({ length: 30 }, (_, i) => {
            const d = new Date();
            d.setDate(d.getDate() - (29 - i));
            return d.toLocaleDateString('id-ID', { day: 'numeric', month: 'short' });
        });
        const data = this.generateRandomData(30, commodity.avgPrice * 0.9, commodity.avgPrice * 1.1);

        if (this.modalChart) this.modalChart.destroy();

        this.modalChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: commodity.name,
                    data,
                    borderColor: this.colors.primary,
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } }
            }
        });
    },

    createSparkline(canvas, data, color = '#22c55e') {
        return new Chart(canvas, {
            type: 'line',
            data: {
                labels: data.map((_, i) => i),
                datasets: [{
                    data,
                    borderColor: color,
                    borderWidth: 2,
                    pointRadius: 0,
                    tension: 0.4,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false }, tooltip: { enabled: false } },
                scales: { x: { display: false }, y: { display: false } }
            }
        });
    },

    generateRandomData(count, min, max) {
        return Array.from({ length: count }, () =>
            Math.floor(Math.random() * (max - min) + min)
        );
    }
};
