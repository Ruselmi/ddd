/**
 * Taniku - Location Module
 * Geolocation detection with IP fallback
 */

const Location = {
    currentLocation: null,

    async init() {
        try {
            const location = await this.detectLocation();
            State.setLocation(location);
            return location;
        } catch (error) {
            console.warn('Location detection failed:', error);
            State.setLocation({ region: 'Indonesia', city: 'Jakarta' });
        }
    },

    async detectLocation() {
        // Try browser geolocation first
        if ('geolocation' in navigator) {
            try {
                const position = await this.getBrowserLocation();
                return await this.reverseGeocode(position.coords.latitude, position.coords.longitude);
            } catch {
                // Fall back to IP-based
                return await this.getIPLocation();
            }
        }
        return await this.getIPLocation();
    },

    getBrowserLocation() {
        return new Promise((resolve, reject) => {
            navigator.geolocation.getCurrentPosition(resolve, reject, {
                timeout: 5000,
                enableHighAccuracy: false
            });
        });
    },

    async reverseGeocode(lat, lng) {
        try {
            const response = await fetch(`https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json`);
            const data = await response.json();
            return {
                lat,
                lng,
                city: data.address?.city || data.address?.county || data.address?.state,
                region: data.address?.state || 'Indonesia',
                country: data.address?.country || 'Indonesia'
            };
        } catch {
            return { lat, lng, region: 'Indonesia' };
        }
    },

    async getIPLocation() {
        try {
            const response = await fetch('http://ip-api.com/json/?fields=status,city,regionName,country,lat,lon');
            const data = await response.json();
            if (data.status === 'success') {
                return {
                    lat: data.lat,
                    lng: data.lon,
                    city: data.city,
                    region: data.regionName,
                    country: data.country
                };
            }
        } catch {
            // Fallback
        }
        return { region: 'Indonesia', city: 'Jakarta' };
    },

    getBPSCode(region) {
        const codeMap = {
            'DKI Jakarta': '3100',
            'Jawa Barat': '3200',
            'Jawa Tengah': '3300',
            'DI Yogyakarta': '3400',
            'Jawa Timur': '3500',
            'Banten': '3600',
            'Bali': '5100',
            // Add more as needed
        };
        return codeMap[region] || '0000';
    }
};
