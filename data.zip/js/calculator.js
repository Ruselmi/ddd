/**
 * Taniku - Calculator Module
 * Unit price, planner, and inflation calculators
 */

const Calculator = {
    plannerItems: [],

    init() {
        this.setupTabs();
        this.setupUnitCalculator();
        this.setupInflationCalculator();
        this.setupPlanner();
    },

    setupTabs() {
        document.querySelectorAll('.calc-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                document.querySelectorAll('.calc-tab').forEach(t => t.classList.remove('active'));
                document.querySelectorAll('.calc-panel').forEach(p => p.classList.remove('active'));

                tab.classList.add('active');
                const panel = document.getElementById(`calc-${tab.dataset.tab}`);
                if (panel) panel.classList.add('active');
            });
        });
    },

    setupUnitCalculator() {
        const btn = document.getElementById('calc-unit-btn');
        if (!btn) return;

        btn.addEventListener('click', () => {
            const priceA = parseFloat(document.getElementById('unit-a-price').value) || 0;
            const weightA = parseFloat(document.getElementById('unit-a-weight').value) || 1;
            const priceB = parseFloat(document.getElementById('unit-b-price').value) || 0;
            const weightB = parseFloat(document.getElementById('unit-b-weight').value) || 1;

            const unitPriceA = Utils.calculatePricePerUnit(priceA, weightA);
            const unitPriceB = Utils.calculatePricePerUnit(priceB, weightB);
            const result = document.getElementById('calc-unit-result');

            const winner = unitPriceA < unitPriceB ? 'A' : 'B';
            const savings = Math.abs(unitPriceA - unitPriceB);

            result.innerHTML = `
                <div style="margin-bottom:12px">
                    <strong>Produk A:</strong> ${Utils.formatCurrency(unitPriceA)}/kg<br>
                    <strong>Produk B:</strong> ${Utils.formatCurrency(unitPriceB)}/kg
                </div>
                <div style="color:#22c55e;font-weight:bold">
                    ✓ Produk ${winner} lebih hemat ${Utils.formatCurrency(savings)}/kg
                </div>
            `;
        });
    },

    setupInflationCalculator() {
        const btn = document.getElementById('calc-inflation-btn');
        if (!btn) return;

        btn.addEventListener('click', () => {
            const current = parseFloat(document.getElementById('inflation-current').value) || 0;
            const rate = parseFloat(document.getElementById('inflation-rate').value) || 5;
            const months = parseFloat(document.getElementById('inflation-months').value) || 12;

            const futurePrice = Utils.calculateInflation(current, rate, months);
            const increase = futurePrice - current;
            const result = document.getElementById('calc-inflation-result');

            result.innerHTML = `
                <div style="margin-bottom:12px">
                    <strong>Harga Saat Ini:</strong> ${Utils.formatCurrency(current)}<br>
                    <strong>Estimasi ${months} Bulan:</strong> ${Utils.formatCurrency(futurePrice)}
                </div>
                <div style="color:#f59e0b">
                    📈 Kenaikan: ${Utils.formatCurrency(increase)} (+${((increase / current) * 100).toFixed(1)}%)
                </div>
            `;
        });
    },

    setupPlanner() {
        const addBtn = document.getElementById('add-planner-item');
        if (!addBtn) return;

        addBtn.addEventListener('click', () => this.addPlannerItem());
        this.renderPlannerList();
    },

    addPlannerItem() {
        const commodities = Commodities.getAll();
        const randomCommodity = commodities[Math.floor(Math.random() * commodities.length)];

        this.plannerItems.push({
            id: Utils.generateId(),
            commodityId: randomCommodity.id,
            name: randomCommodity.name,
            price: randomCommodity.avgPrice,
            quantity: 1
        });

        this.renderPlannerList();
    },

    renderPlannerList() {
        const list = document.getElementById('planner-list');
        const total = document.getElementById('planner-total');
        if (!list) return;

        list.innerHTML = this.plannerItems.map(item => `
            <div class="planner-item" style="display:flex;gap:12px;align-items:center;padding:12px;background:var(--bg-tertiary);border-radius:8px;margin-bottom:8px">
                <span style="flex:1">${item.name}</span>
                <input type="number" value="${item.quantity}" min="1" 
                    style="width:60px;padding:4px 8px;background:var(--bg-secondary);border:1px solid var(--border-color);border-radius:4px;color:var(--text-primary)"
                    onchange="Calculator.updateQuantity('${item.id}', this.value)">
                <span style="width:120px;text-align:right">${Utils.formatCurrency(item.price * item.quantity)}</span>
                <button onclick="Calculator.removeItem('${item.id}')" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:18px">×</button>
            </div>
        `).join('');

        const totalAmount = this.plannerItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        if (total) total.textContent = `Total: ${Utils.formatCurrency(totalAmount)}`;
    },

    updateQuantity(id, value) {
        const item = this.plannerItems.find(i => i.id === id);
        if (item) {
            item.quantity = Math.max(1, parseInt(value) || 1);
            this.renderPlannerList();
        }
    },

    removeItem(id) {
        this.plannerItems = this.plannerItems.filter(i => i.id !== id);
        this.renderPlannerList();
    }
};
