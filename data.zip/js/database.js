/**
 * Taniku - Database Module
 * IndexedDB wrapper for offline commodity data storage
 */

const Database = {
    DB_NAME: 'TanikuDB',
    DB_VERSION: 1,
    _db: null,

    // Initialize database
    async init() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.DB_NAME, this.DB_VERSION);

            request.onerror = () => reject(request.error);
            request.onsuccess = () => {
                this._db = request.result;
                resolve(this._db);
            };

            request.onupgradeneeded = (event) => {
                const db = event.target.result;

                // Commodities store
                if (!db.objectStoreNames.contains('commodities')) {
                    const commoditiesStore = db.createObjectStore('commodities', { keyPath: 'id' });
                    commoditiesStore.createIndex('category', 'category', { unique: false });
                    commoditiesStore.createIndex('name', 'name', { unique: false });
                }

                // Price history store
                if (!db.objectStoreNames.contains('priceHistory')) {
                    const priceStore = db.createObjectStore('priceHistory', { keyPath: 'id' });
                    priceStore.createIndex('commodityId', 'commodityId', { unique: false });
                    priceStore.createIndex('date', 'date', { unique: false });
                }

                // Settings store
                if (!db.objectStoreNames.contains('settings')) {
                    db.createObjectStore('settings', { keyPath: 'key' });
                }

                // Cache store
                if (!db.objectStoreNames.contains('cache')) {
                    const cacheStore = db.createObjectStore('cache', { keyPath: 'key' });
                    cacheStore.createIndex('expiry', 'expiry', { unique: false });
                }
            };
        });
    },

    // Generic CRUD operations
    async add(storeName, data) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.add(data);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    async put(storeName, data) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.put(data);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    async get(storeName, key) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const request = store.get(key);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    async getAll(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction(storeName, 'readonly');
            const store = tx.objectStore(storeName);
            const request = store.getAll();
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    async delete(storeName, key) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.delete(key);
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    },

    async clear(storeName) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);
            const request = store.clear();
            request.onsuccess = () => resolve();
            request.onerror = () => reject(request.error);
        });
    },

    // Bulk operations
    async bulkPut(storeName, items) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction(storeName, 'readwrite');
            const store = tx.objectStore(storeName);

            items.forEach(item => store.put(item));

            tx.oncomplete = () => resolve();
            tx.onerror = () => reject(tx.error);
        });
    },

    // Cache operations with expiry
    async setCache(key, value, ttlMinutes = 30) {
        const expiry = Date.now() + (ttlMinutes * 60 * 1000);
        await this.put('cache', { key, value, expiry });
    },

    async getCache(key) {
        const cached = await this.get('cache', key);
        if (!cached) return null;
        if (Date.now() > cached.expiry) {
            await this.delete('cache', key);
            return null;
        }
        return cached.value;
    },

    async clearExpiredCache() {
        const all = await this.getAll('cache');
        const now = Date.now();
        for (const item of all) {
            if (now > item.expiry) {
                await this.delete('cache', item.key);
            }
        }
    },

    // Settings operations
    async getSetting(key, defaultValue = null) {
        const result = await this.get('settings', key);
        return result ? result.value : defaultValue;
    },

    async setSetting(key, value) {
        await this.put('settings', { key, value });
    },

    // Sync operations
    async getLastSync() {
        return await this.getSetting('lastSync');
    },

    async setLastSync(timestamp = new Date().toISOString()) {
        await this.setSetting('lastSync', timestamp);
    },

    // Commodity operations
    async saveCommodities(commodities) {
        await this.bulkPut('commodities', commodities);
        await this.setLastSync();
    },

    async getCommodities() {
        return await this.getAll('commodities');
    },

    async getCommodityById(id) {
        return await this.get('commodities', id);
    },

    async getCommoditiesByCategory(category) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction('commodities', 'readonly');
            const store = tx.objectStore('commodities');
            const index = store.index('category');
            const request = index.getAll(category);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    },

    // Price history operations
    async savePriceHistory(commodityId, prices) {
        const items = prices.map((price, idx) => ({
            id: `${commodityId}-${idx}`,
            commodityId,
            ...price
        }));
        await this.bulkPut('priceHistory', items);
    },

    async getPriceHistory(commodityId) {
        return new Promise((resolve, reject) => {
            const tx = this._db.transaction('priceHistory', 'readonly');
            const store = tx.objectStore('priceHistory');
            const index = store.index('commodityId');
            const request = index.getAll(commodityId);
            request.onsuccess = () => resolve(request.result);
            request.onerror = () => reject(request.error);
        });
    }
};

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Database;
}
