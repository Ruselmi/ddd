/**
 * Taniku - Main Application
 * Entry point and initialization
 */

const App = {
    async init() {
        try {
            State.showLoading('Menginisialisasi...');
            State.updateLoadingProgress(20, 'Memuat tema...');
            State.loadTheme();

            State.updateLoadingProgress(40, 'Memuat data komoditas...');
            // Load directly from Commodities (fast, no async needed)
            const commodities = Commodities.getAll();
            this.renderCommoditiesGrid(commodities);

            State.updateLoadingProgress(60, 'Menyiapkan tampilan...');
            Charts.init();
            Charts.renderWeeklyChart();
            Charts.renderCategoryChart();
            this.renderTopMovers();
            this.renderInternational();
            Calculator.init();

            State.updateLoadingProgress(80, 'Menyelesaikan...');
            this.setupEventListeners();
            this.updateStats();

            State.updateLoadingProgress(100, 'Selesai!');
            setTimeout(() => State.hideLoading(), 300);

            // Initialize map when page is shown
            State.on('currentPageChanged', ({ value }) => {
                if (value === 'peta') {
                    setTimeout(() => {
                        MapModule.init();
                        MapModule.resize();
                    }, 100);
                }
            });

            // Detect location in background
            Location.init();
            State.setSyncStatus('success', 'Data lokal');

        } catch (error) {
            console.error('App init error:', error);
            State.hideLoading();
        }
    },

    updateStats() {
        const all = Commodities.getAll();
        document.getElementById('stat-commodities').textContent = all.length;
        document.getElementById('stat-up').textContent = Commodities.getPriceUp().length;
        document.getElementById('stat-down').textContent = Commodities.getPriceDown().length;
    },

    renderInternational() {
        const grid = document.getElementById('intl-grid');
        if (!grid) return;

        const data = API.getDefaultInternationalPrices();
        grid.innerHTML = data.map(item => {
            const localPrice = API.convertToIDR(item.priceUSD);
            return `
                <div class="intl-card">
                    <h3 style="margin-bottom:8px">${item.name}</h3>
                    <div style="color:var(--text-muted);font-size:0.875rem">${item.symbol}</div>
                    <div class="intl-prices">
                        <div class="intl-price-item">
                            <div class="intl-price-label">Internasional</div>
                            <div class="intl-price-value global">$${item.priceUSD}/${item.unit}</div>
                        </div>
                        <div class="intl-price-item">
                            <div class="intl-price-label">Lokal (IDR)</div>
                            <div class="intl-price-value local">${Utils.formatCurrency(localPrice)}</div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    },

    async loadCommodities() {
        const commodities = Commodities.getAll();
        this.renderCommoditiesGrid(commodities);
        return commodities;
    },

    renderCommoditiesGrid(commodities) {
        const grid = document.getElementById('commodities-grid');
        if (!grid) return;

        grid.innerHTML = commodities.map(c => `
            <div class="commodity-card" data-id="${c.id}">
                <div class="commodity-header">
                    <div class="commodity-icon">${c.icon}</div>
                    <div>
                        <div class="commodity-name">${c.name}</div>
                        <div class="commodity-category">${c.category}</div>
                    </div>
                </div>
                <div class="commodity-price">${Utils.formatCurrency(c.avgPrice)}</div>
                <div class="commodity-change ${c.change >= 0 ? 'up' : 'down'}">
                    ${c.change >= 0 ? '↑' : '↓'} ${Utils.formatChange(c.change)}
                </div>
            </div>
        `).join('');

        // Add click handlers
        grid.querySelectorAll('.commodity-card').forEach(card => {
            card.addEventListener('click', () => this.showCommodityModal(card.dataset.id));
        });
    },

    renderTopMovers() {
        const container = document.getElementById('top-movers');
        if (!container) return;

        const movers = Commodities.getTopMovers(6);
        container.innerHTML = movers.map(c => `
            <div class="mover-card">
                <div class="mover-icon">${c.icon}</div>
                <div class="mover-info">
                    <div class="mover-name">${c.name}</div>
                    <div class="mover-change ${c.change >= 0 ? 'up' : 'down'}">
                        ${c.change >= 0 ? '↑' : '↓'} ${Utils.formatChange(c.change)}
                    </div>
                </div>
            </div>
        `).join('');
    },

    showCommodityModal(id) {
        const commodity = Commodities.getById(id);
        if (!commodity) return;

        const modal = document.getElementById('commodity-modal');
        modal.querySelector('#modal-icon').textContent = commodity.icon;
        modal.querySelector('#modal-title').textContent = commodity.name;

        // Render sub-commodities
        const subList = modal.querySelector('#sub-commodities');
        subList.innerHTML = commodity.subCommodities.map(sub => `
            <div class="sub-commodity-item">
                <div>
                    <div class="sub-commodity-name">${sub.name}</div>
                    <div class="sub-commodity-variety">${sub.variety}</div>
                </div>
                <div>
                    <div class="sub-commodity-price">${Utils.formatCurrency(sub.price)}</div>
                    <div class="commodity-change ${sub.change >= 0 ? 'up' : 'down'}" 
                         style="font-size:0.75rem">${Utils.formatChange(sub.change)}</div>
                </div>
            </div>
        `).join('');

        Charts.renderModalChart(commodity);
        modal.classList.add('active');
    },

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                State.navigateTo(item.dataset.page);
            });
        });

        // Theme toggle
        document.getElementById('theme-toggle')?.addEventListener('click', () => State.toggleTheme());

        // Modal close
        document.getElementById('modal-close')?.addEventListener('click', () => {
            document.getElementById('commodity-modal').classList.remove('active');
        });
        document.querySelector('.modal-backdrop')?.addEventListener('click', () => {
            document.getElementById('commodity-modal').classList.remove('active');
        });

        // Menu toggle (mobile)
        document.getElementById('menu-toggle')?.addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('open');
        });

        // Search
        const searchInput = document.getElementById('search-input');
        if (searchInput) {
            searchInput.addEventListener('input', Utils.debounce((e) => {
                const results = Commodities.search(e.target.value);
                this.renderCommoditiesGrid(results);
            }, 300));
        }

        // Category filters
        document.querySelectorAll('.filter-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
                chip.classList.add('active');
                const commodities = Commodities.getByCategory(chip.dataset.category);
                this.renderCommoditiesGrid(commodities);
            });
        });
    },

    startBackgroundSync() {
        setInterval(async () => {
            if (navigator.onLine) {
                await API.syncAll();
            } else {
                State.setSyncStatus('offline');
            }
        }, 30 * 60 * 1000); // Every 30 minutes

        window.addEventListener('online', () => API.syncAll());
        window.addEventListener('offline', () => State.setSyncStatus('offline'));
    }
};

// Start app
document.addEventListener('DOMContentLoaded', () => App.init());
