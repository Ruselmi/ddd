/**
 * Taniku - API Module
 * BPS API integration and international price data
 */

const API = {
    BPS_BASE_URL: '/api/bps',
    _exchangeRate: 15850,

    async fetchWithRetry(url, options = {}, retries = 3) {
        for (let i = 0; i < retries; i++) {
            try {
                const response = await fetch(url, options);
                if (!response.ok) throw new Error(`HTTP ${response.status}`);
                return await response.json();
            } catch (error) {
                if (i === retries - 1) throw error;
                await new Promise(r => setTimeout(r, Math.pow(2, i) * 1000));
            }
        }
    },

    async getExchangeRate() {
        try {
            const data = await this.fetchWithRetry('/api/exchange-rate');
            this._exchangeRate = data.USD_IDR;
            return data;
        } catch {
            return { USD_IDR: this._exchangeRate };
        }
    },

    convertToIDR(usdAmount) {
        return usdAmount * this._exchangeRate;
    },

    async getCommodityPrices() {
        try {
            State.setSyncStatus('loading');
            const data = await this.fetchBPSData('list/model/data/domain/0000/var/1714');
            State.setSyncStatus('success');
            return data;
        } catch {
            return await this.getLocalCommodities();
        }
    },

    async getLocalCommodities() {
        try {
            const cached = await Database.getCommodities();
            if (cached && cached.length > 0) return cached;
            const response = await fetch('/data/commodities-db.json');
            const data = await response.json();
            await Database.saveCommodities(data);
            return data;
        } catch {
            return Commodities.getAll();
        }
    },

    async getInternationalPrices() {
        try {
            const response = await fetch('/data/intl-prices.json');
            return await response.json();
        } catch {
            return this.getDefaultInternationalPrices();
        }
    },

    getDefaultInternationalPrices() {
        return [
            { name: 'Beras', symbol: 'RICE', priceUSD: 0.48, unit: 'kg' },
            { name: 'Gandum', symbol: 'WHEAT', priceUSD: 0.25, unit: 'kg' },
            { name: 'Jagung', symbol: 'CORN', priceUSD: 0.18, unit: 'kg' },
            { name: 'Kedelai', symbol: 'SOYBEAN', priceUSD: 0.42, unit: 'kg' },
            { name: 'Gula', symbol: 'SUGAR', priceUSD: 0.52, unit: 'kg' },
            { name: 'Kopi', symbol: 'COFFEE', priceUSD: 5.80, unit: 'kg' },
            { name: 'Minyak Sawit', symbol: 'PALM_OIL', priceUSD: 0.85, unit: 'liter' }
        ];
    },

    async syncAll() {
        State.setSyncStatus('loading');
        try {
            await Promise.all([this.getCommodityPrices(), this.getExchangeRate()]);
            State.setSyncStatus('success');
            return true;
        } catch {
            State.setSyncStatus('error');
            return false;
        }
    }
};
