/**
 * Taniku - Commodities Module
 * 40 Indonesian commodity definitions with sub-commodities
 */

const Commodities = {
    categories: ['Pangan', 'Sayuran', 'Buah', 'Protein', 'Bumbu', 'Perkebunan'],

    data: [
        // PANGAN (10 items)
        {
            id: 'C001', name: 'Beras', icon: '🌾', category: 'Pangan', unit: 'kg', avgPrice: 14000, change: 2.5,
            subCommodities: [
                { id: 'C001-01', name: 'Beras Premium', variety: 'Grade A', price: 16500, change: 1.8 },
                { id: 'C001-02', name: 'Beras Medium', variety: 'Grade B', price: 13500, change: 2.1 },
                { id: 'C001-03', name: 'Beras IR64', variety: 'Lokal', price: 12800, change: 3.2 },
                { id: 'C001-04', name: 'Beras Pandan Wangi', variety: 'Aromatik', price: 18000, change: 1.5 },
                { id: 'C001-05', name: 'Beras Merah', variety: 'Organik', price: 22000, change: 0.8 },
                { id: 'C001-06', name: 'Beras Ketan Putih', variety: 'Ketan', price: 19500, change: -0.5 },
                { id: 'C001-07', name: 'Beras Ketan Hitam', variety: 'Ketan', price: 24000, change: 1.2 },
                { id: 'C001-08', name: 'Beras Rojolele', variety: 'Premium', price: 17500, change: 2.0 },
                { id: 'C001-09', name: 'Beras Ciherang', variety: 'Unggul', price: 14200, change: 2.8 },
                { id: 'C001-10', name: 'Beras Kepala', variety: 'Super', price: 15800, change: 1.9 }
            ]
        },
        {
            id: 'C002', name: 'Jagung', icon: '🌽', category: 'Pangan', unit: 'kg', avgPrice: 6500, change: -1.2,
            subCommodities: [
                { id: 'C002-01', name: 'Jagung Pipilan Kering', variety: 'Kering', price: 6200, change: -1.5 },
                { id: 'C002-02', name: 'Jagung Manis', variety: 'Sweet Corn', price: 8500, change: 0.8 },
                { id: 'C002-03', name: 'Jagung Popcorn', variety: 'Pop', price: 12000, change: 0.5 },
                { id: 'C002-04', name: 'Jagung Pulut', variety: 'Waxy', price: 7500, change: -0.3 },
                { id: 'C002-05', name: 'Jagung Baby', variety: 'Baby Corn', price: 18000, change: 1.2 },
                { id: 'C002-06', name: 'Jagung Kuning', variety: 'Yellow', price: 6000, change: -1.8 },
                { id: 'C002-07', name: 'Jagung Putih', variety: 'White', price: 6800, change: -0.9 },
                { id: 'C002-08', name: 'Jagung Hibrida', variety: 'Hybrid', price: 7200, change: 0.2 },
                { id: 'C002-09', name: 'Jagung Lokal', variety: 'Tradisional', price: 5800, change: -2.1 },
                { id: 'C002-10', name: 'Tepung Jagung', variety: 'Olahan', price: 15000, change: 0.4 }
            ]
        },
        {
            id: 'C003', name: 'Kedelai', icon: '🫘', category: 'Pangan', unit: 'kg', avgPrice: 12000, change: 3.8,
            subCommodities: [
                { id: 'C003-01', name: 'Kedelai Lokal', variety: 'Lokal', price: 11500, change: 4.2 },
                { id: 'C003-02', name: 'Kedelai Impor', variety: 'Import', price: 10800, change: 3.5 },
                { id: 'C003-03', name: 'Kedelai Hitam', variety: 'Black', price: 14000, change: 2.8 },
                { id: 'C003-04', name: 'Kedelai Organik', variety: 'Organic', price: 18000, change: 1.5 },
                { id: 'C003-05', name: 'Kedelai Edamame', variety: 'Edamame', price: 25000, change: 0.8 },
                { id: 'C003-06', name: 'Tempe Kedelai', variety: 'Olahan', price: 8000, change: 5.2 },
                { id: 'C003-07', name: 'Tahu Putih', variety: 'Olahan', price: 12000, change: 4.8 },
                { id: 'C003-08', name: 'Kecap Kedelai', variety: 'Olahan', price: 22000, change: 1.2 },
                { id: 'C003-09', name: 'Susu Kedelai', variety: 'Olahan', price: 15000, change: 2.0 },
                { id: 'C003-10', name: 'Tauco', variety: 'Fermentasi', price: 28000, change: 0.5 }
            ]
        },
        {
            id: 'C004', name: 'Gula Pasir', icon: '🧂', category: 'Pangan', unit: 'kg', avgPrice: 17500, change: 0.8,
            subCommodities: [
                { id: 'C004-01', name: 'Gula Pasir Premium', variety: 'Premium', price: 18500, change: 0.5 },
                { id: 'C004-02', name: 'Gula Pasir Lokal', variety: 'Lokal', price: 16800, change: 1.2 },
                { id: 'C004-03', name: 'Gula Merah Tebu', variety: 'Palm', price: 22000, change: -0.3 },
                { id: 'C004-04', name: 'Gula Aren', variety: 'Aren', price: 35000, change: 0.8 },
                { id: 'C004-05', name: 'Gula Kelapa', variety: 'Coconut', price: 28000, change: 1.5 },
                { id: 'C004-06', name: 'Gula Batu', variety: 'Rock', price: 25000, change: 0.2 },
                { id: 'C004-07', name: 'Gula Halus', variety: 'Fine', price: 19500, change: 0.6 },
                { id: 'C004-08', name: 'Gula Cair', variety: 'Liquid', price: 15000, change: 0.9 },
                { id: 'C004-09', name: 'Gula Stevia', variety: 'Diet', price: 85000, change: -0.2 },
                { id: 'C004-10', name: 'Gula Jagung', variety: 'HFCS', price: 12000, change: 0.4 }
            ]
        },
        {
            id: 'C005', name: 'Minyak Goreng', icon: '🫒', category: 'Pangan', unit: 'liter', avgPrice: 18000, change: -2.5,
            subCommodities: [
                { id: 'C005-01', name: 'Minyak Sawit', variety: 'Palm', price: 17500, change: -2.8 },
                { id: 'C005-02', name: 'Minyak Kelapa', variety: 'Coconut', price: 32000, change: -0.5 },
                { id: 'C005-03', name: 'Minyak Curah', variety: 'Bulk', price: 15500, change: -3.2 },
                { id: 'C005-04', name: 'Minyak Kemasan', variety: 'Branded', price: 19500, change: -1.8 },
                { id: 'C005-05', name: 'Minyak Zaitun', variety: 'Olive', price: 125000, change: 0.2 },
                { id: 'C005-06', name: 'Minyak Canola', variety: 'Canola', price: 48000, change: 0.5 },
                { id: 'C005-07', name: 'Minyak Kedelai', variety: 'Soy', price: 28000, change: -1.2 },
                { id: 'C005-08', name: 'Minyak Wijen', variety: 'Sesame', price: 75000, change: 0.8 },
                { id: 'C005-09', name: 'Minyak Jagung', variety: 'Corn', price: 42000, change: -0.3 },
                { id: 'C005-10', name: 'Minyak Bimoli', variety: 'Premium', price: 21000, change: -2.0 }
            ]
        },
        {
            id: 'C006', name: 'Tepung Terigu', icon: '🌾', category: 'Pangan', unit: 'kg', avgPrice: 12500, change: 1.2,
            subCommodities: [
                { id: 'C006-01', name: 'Terigu Protein Tinggi', variety: 'High', price: 14500, change: 0.8 },
                { id: 'C006-02', name: 'Terigu Protein Sedang', variety: 'Medium', price: 12000, change: 1.5 },
                { id: 'C006-03', name: 'Terigu Protein Rendah', variety: 'Low', price: 11000, change: 1.8 },
                { id: 'C006-04', name: 'Tepung Kue', variety: 'Cake', price: 15500, change: 0.5 },
                { id: 'C006-05', name: 'Tepung Roti', variety: 'Bread', price: 16000, change: 0.3 },
                { id: 'C006-06', name: 'Tepung Serbaguna', variety: 'All Purpose', price: 13000, change: 1.2 },
                { id: 'C006-07', name: 'Tepung Beras', variety: 'Rice', price: 18000, change: 2.0 },
                { id: 'C006-08', name: 'Tepung Tapioka', variety: 'Tapioca', price: 14000, change: 1.0 },
                { id: 'C006-09', name: 'Tepung Maizena', variety: 'Corn Starch', price: 22000, change: 0.4 },
                { id: 'C006-10', name: 'Tepung Mocaf', variety: 'Cassava', price: 16500, change: 0.6 }
            ]
        },
        // Continue with more commodities...
        {
            id: 'C007', name: 'Cabai Merah', icon: '🌶️', category: 'Bumbu', unit: 'kg', avgPrice: 45000, change: 15.5,
            subCommodities: [
                { id: 'C007-01', name: 'Cabai Merah Besar', variety: 'Besar', price: 42000, change: 18.2 },
                { id: 'C007-02', name: 'Cabai Merah Keriting', variety: 'Keriting', price: 48000, change: 12.5 },
                { id: 'C007-03', name: 'Cabai Rawit Merah', variety: 'Rawit', price: 55000, change: 20.8 },
                { id: 'C007-04', name: 'Cabai Rawit Hijau', variety: 'Rawit Hijau', price: 52000, change: 18.5 },
                { id: 'C007-05', name: 'Cabai Hijau Besar', variety: 'Hijau', price: 35000, change: 10.2 },
                { id: 'C007-06', name: 'Cabai Paprika Merah', variety: 'Paprika', price: 65000, change: 5.5 },
                { id: 'C007-07', name: 'Cabai Paprika Hijau', variety: 'Paprika', price: 58000, change: 4.8 },
                { id: 'C007-08', name: 'Cabai Gochugaru', variety: 'Korea', price: 85000, change: 2.0 },
                { id: 'C007-09', name: 'Cabai Bubuk', variety: 'Powder', price: 75000, change: 8.5 },
                { id: 'C007-10', name: 'Cabai Kering', variety: 'Dried', price: 120000, change: 5.2 }
            ]
        },
        {
            id: 'C008', name: 'Bawang Merah', icon: '🧅', category: 'Bumbu', unit: 'kg', avgPrice: 38000, change: 8.2,
            subCommodities: [
                { id: 'C008-01', name: 'Bawang Merah Brebes', variety: 'Brebes', price: 36000, change: 9.5 },
                { id: 'C008-02', name: 'Bawang Merah Nganjuk', variety: 'Nganjuk', price: 38500, change: 7.8 },
                { id: 'C008-03', name: 'Bawang Merah Impor', variety: 'Import', price: 32000, change: 5.2 },
                { id: 'C008-04', name: 'Bawang Merah Lokal', variety: 'Lokal', price: 35000, change: 10.5 },
                { id: 'C008-05', name: 'Bawang Merah Super', variety: 'Super', price: 42000, change: 6.8 },
                { id: 'C008-06', name: 'Bawang Goreng', variety: 'Fried', price: 95000, change: 3.2 },
                { id: 'C008-07', name: 'Bawang Merah Kupas', variety: 'Peeled', price: 48000, change: 8.0 },
                { id: 'C008-08', name: 'Bawang Merah Iris', variety: 'Sliced', price: 55000, change: 4.5 },
                { id: 'C008-09', name: 'Bawang Merah Bubuk', variety: 'Powder', price: 120000, change: 2.8 },
                { id: 'C008-10', name: 'Bawang Dayak', variety: 'Dayak', price: 85000, change: 1.5 }
            ]
        },
        {
            id: 'C009', name: 'Bawang Putih', icon: '🧄', category: 'Bumbu', unit: 'kg', avgPrice: 32000, change: -3.5,
            subCommodities: [
                { id: 'C009-01', name: 'Bawang Putih Lokal', variety: 'Lokal', price: 45000, change: -2.0 },
                { id: 'C009-02', name: 'Bawang Putih Kating', variety: 'Kating', price: 28000, change: -4.5 },
                { id: 'C009-03', name: 'Bawang Putih Impor', variety: 'China', price: 26000, change: -5.2 },
                { id: 'C009-04', name: 'Bawang Putih Tunggal', variety: 'Single', price: 75000, change: 0.8 },
                { id: 'C009-05', name: 'Bawang Hitam', variety: 'Black', price: 180000, change: 1.2 },
                { id: 'C009-06', name: 'Bawang Putih Goreng', variety: 'Fried', price: 85000, change: -1.5 },
                { id: 'C009-07', name: 'Bawang Putih Kupas', variety: 'Peeled', price: 38000, change: -3.8 },
                { id: 'C009-08', name: 'Bawang Putih Cincang', variety: 'Minced', price: 42000, change: -2.5 },
                { id: 'C009-09', name: 'Bawang Putih Bubuk', variety: 'Powder', price: 95000, change: -0.8 },
                { id: 'C009-10', name: 'Bawang Bombay', variety: 'Onion', price: 28000, change: -4.0 }
            ]
        },
        {
            id: 'C010', name: 'Telur Ayam', icon: '🥚', category: 'Protein', unit: 'kg', avgPrice: 28000, change: 1.8,
            subCommodities: [
                { id: 'C010-01', name: 'Telur Ayam Ras', variety: 'Layer', price: 27500, change: 2.0 },
                { id: 'C010-02', name: 'Telur Ayam Kampung', variety: 'Kampung', price: 48000, change: 1.2 },
                { id: 'C010-03', name: 'Telur Ayam Omega', variety: 'Omega-3', price: 38000, change: 0.8 },
                { id: 'C010-04', name: 'Telur Ayam Organik', variety: 'Organic', price: 55000, change: 0.5 },
                { id: 'C010-05', name: 'Telur Bebek', variety: 'Duck', price: 35000, change: 1.5 },
                { id: 'C010-06', name: 'Telur Puyuh', variety: 'Quail', price: 45000, change: 2.2 },
                { id: 'C010-07', name: 'Telur Asin', variety: 'Salted', price: 4500, change: 1.0 },
                { id: 'C010-08', name: 'Telur Balado', variety: 'Processed', price: 5500, change: 0.5 },
                { id: 'C010-09', name: 'Telur Setengah Matang', variety: 'Soft Boil', price: 3000, change: 1.8 },
                { id: 'C010-10', name: 'Telur Omega Premium', variety: 'Premium', price: 42000, change: 0.6 }
            ]
        },
        // SAYURAN
        {
            id: 'C011', name: 'Tomat', icon: '🍅', category: 'Sayuran', unit: 'kg', avgPrice: 12000, change: 5.2,
            subCommodities: [
                { id: 'C011-01', name: 'Tomat Merah', variety: 'Merah', price: 12000, change: 5.5 },
                { id: 'C011-02', name: 'Tomat Cherry', variety: 'Cherry', price: 35000, change: 2.0 },
                { id: 'C011-03', name: 'Tomat Sayur', variety: 'Lokal', price: 11000, change: 5.8 }
            ]
        },
        {
            id: 'C012', name: 'Kentang', icon: '🥔', category: 'Sayuran', unit: 'kg', avgPrice: 14000, change: -2.1,
            subCommodities: [
                { id: 'C012-01', name: 'Kentang Granola', variety: 'Granola', price: 15000, change: -1.8 },
                { id: 'C012-02', name: 'Kentang Dieng', variety: 'Dieng', price: 18000, change: -1.2 },
                { id: 'C012-03', name: 'Kentang Lokal', variety: 'Lokal', price: 12000, change: -3.2 }
            ]
        },
        {
            id: 'C013', name: 'Wortel', icon: '🥕', category: 'Sayuran', unit: 'kg', avgPrice: 16000, change: 1.5,
            subCommodities: [
                { id: 'C013-01', name: 'Wortel Lokal', variety: 'Lokal', price: 15000, change: 1.8 },
                { id: 'C013-02', name: 'Wortel Baby', variety: 'Baby', price: 35000, change: 0.8 },
                { id: 'C013-03', name: 'Wortel Berastagi', variety: 'Berastagi', price: 18000, change: 2.0 }
            ]
        },
        {
            id: 'C014', name: 'Kubis', icon: '🥬', category: 'Sayuran', unit: 'kg', avgPrice: 8000, change: -3.5,
            subCommodities: [
                { id: 'C014-01', name: 'Kubis Putih', variety: 'White', price: 7500, change: -4.0 },
                { id: 'C014-02', name: 'Sawi Hijau', variety: 'Green', price: 8500, change: -3.8 },
                { id: 'C014-03', name: 'Pakcoy', variety: 'Bok Choy', price: 12000, change: -2.5 }
            ]
        },
        {
            id: 'C015', name: 'Brokoli', icon: '🥦', category: 'Sayuran', unit: 'kg', avgPrice: 28000, change: 0.8,
            subCommodities: [
                { id: 'C015-01', name: 'Brokoli Hijau', variety: 'Green', price: 28000, change: 0.8 },
                { id: 'C015-02', name: 'Kembang Kol', variety: 'Cauliflower', price: 22000, change: 1.2 },
                { id: 'C015-03', name: 'Brokoli Organik', variety: 'Organic', price: 45000, change: 0.3 }
            ]
        },
        {
            id: 'C016', name: 'Terong', icon: '🍆', category: 'Sayuran', unit: 'kg', avgPrice: 12000, change: 2.5,
            subCommodities: [
                { id: 'C016-01', name: 'Terong Ungu', variety: 'Purple', price: 12000, change: 2.8 },
                { id: 'C016-02', name: 'Terong Hijau', variety: 'Green', price: 10000, change: 3.2 },
                { id: 'C016-03', name: 'Terong Belanda', variety: 'Tamarillo', price: 35000, change: 0.8 }
            ]
        },
        {
            id: 'C017', name: 'Timun', icon: '🥒', category: 'Sayuran', unit: 'kg', avgPrice: 8000, change: -1.8,
            subCommodities: [
                { id: 'C017-01', name: 'Timun Lokal', variety: 'Lokal', price: 7000, change: -2.2 },
                { id: 'C017-02', name: 'Labu Siam', variety: 'Chayote', price: 10000, change: -1.5 },
                { id: 'C017-03', name: 'Pare', variety: 'Bitter', price: 15000, change: 0.8 }
            ]
        },
        {
            id: 'C018', name: 'Kangkung', icon: '🥬', category: 'Sayuran', unit: 'ikat', avgPrice: 5000, change: 3.2,
            subCommodities: [
                { id: 'C018-01', name: 'Kangkung Darat', variety: 'Darat', price: 5000, change: 3.5 },
                { id: 'C018-02', name: 'Bayam Hijau', variety: 'Spinach', price: 6000, change: 2.8 },
                { id: 'C018-03', name: 'Daun Singkong', variety: 'Cassava', price: 4000, change: 4.0 }
            ]
        },
        // BUAH
        {
            id: 'C019', name: 'Pisang', icon: '🍌', category: 'Buah', unit: 'sisir', avgPrice: 18000, change: 1.2,
            subCommodities: [
                { id: 'C019-01', name: 'Pisang Ambon', variety: 'Ambon', price: 22000, change: 0.8 },
                { id: 'C019-02', name: 'Pisang Cavendish', variety: 'Cavendish', price: 25000, change: 0.5 },
                { id: 'C019-03', name: 'Pisang Kepok', variety: 'Kepok', price: 15000, change: 1.8 }
            ]
        },
        {
            id: 'C020', name: 'Jeruk', icon: '🍊', category: 'Buah', unit: 'kg', avgPrice: 22000, change: -0.5,
            subCommodities: [
                { id: 'C020-01', name: 'Jeruk Sunkist', variety: 'Sunkist', price: 35000, change: -0.2 },
                { id: 'C020-02', name: 'Jeruk Medan', variety: 'Medan', price: 22000, change: -0.5 },
                { id: 'C020-03', name: 'Jeruk Nipis', variety: 'Lime', price: 18000, change: 2.5 }
            ]
        },
        {
            id: 'C021', name: 'Apel', icon: '🍎', category: 'Buah', unit: 'kg', avgPrice: 35000, change: 0.8,
            subCommodities: [
                { id: 'C021-01', name: 'Apel Malang', variety: 'Malang', price: 28000, change: 1.2 },
                { id: 'C021-02', name: 'Apel Fuji', variety: 'Fuji', price: 42000, change: 0.5 },
                { id: 'C021-03', name: 'Apel Washington', variety: 'Washington', price: 48000, change: 0.3 }
            ]
        },
        {
            id: 'C022', name: 'Mangga', icon: '🥭', category: 'Buah', unit: 'kg', avgPrice: 25000, change: 4.5,
            subCommodities: [
                { id: 'C022-01', name: 'Mangga Harum Manis', variety: 'Harum Manis', price: 28000, change: 5.0 },
                { id: 'C022-02', name: 'Mangga Gedong', variety: 'Gedong', price: 35000, change: 3.5 },
                { id: 'C022-03', name: 'Mangga Indramayu', variety: 'Indramayu', price: 22000, change: 5.5 }
            ]
        },
        {
            id: 'C023', name: 'Anggur', icon: '🍇', category: 'Buah', unit: 'kg', avgPrice: 55000, change: -1.2,
            subCommodities: [
                { id: 'C023-01', name: 'Anggur Merah', variety: 'Red Globe', price: 52000, change: -1.5 },
                { id: 'C023-02', name: 'Anggur Hijau', variety: 'Green', price: 58000, change: -0.8 },
                { id: 'C023-03', name: 'Anggur Hitam', variety: 'Black', price: 62000, change: -1.0 }
            ]
        },
        {
            id: 'C024', name: 'Semangka', icon: '🍉', category: 'Buah', unit: 'kg', avgPrice: 8000, change: 2.8,
            subCommodities: [
                { id: 'C024-01', name: 'Semangka Merah', variety: 'Red', price: 8000, change: 3.0 },
                { id: 'C024-02', name: 'Melon Hijau', variety: 'Honeydew', price: 18000, change: 1.8 },
                { id: 'C024-03', name: 'Semangka Kuning', variety: 'Yellow', price: 12000, change: 2.0 }
            ]
        },
        {
            id: 'C025', name: 'Pepaya', icon: '🍑', category: 'Buah', unit: 'kg', avgPrice: 10000, change: 1.5,
            subCommodities: [
                { id: 'C025-01', name: 'Pepaya California', variety: 'California', price: 12000, change: 1.2 },
                { id: 'C025-02', name: 'Pepaya Thailand', variety: 'Thailand', price: 15000, change: 0.8 },
                { id: 'C025-03', name: 'Pepaya Lokal', variety: 'Lokal', price: 8000, change: 2.0 }
            ]
        },
        // PROTEIN
        {
            id: 'C026', name: 'Daging Sapi', icon: '🥩', category: 'Protein', unit: 'kg', avgPrice: 130000, change: 1.5,
            subCommodities: [
                { id: 'C026-01', name: 'Has Dalam', variety: 'Tenderloin', price: 180000, change: 1.0 },
                { id: 'C026-02', name: 'Daging Giling', variety: 'Ground', price: 115000, change: 1.9 },
                { id: 'C026-03', name: 'Iga Sapi', variety: 'Ribs', price: 145000, change: 1.5 }
            ]
        },
        {
            id: 'C027', name: 'Daging Ayam', icon: '🍗', category: 'Protein', unit: 'kg', avgPrice: 35000, change: 2.2,
            subCommodities: [
                { id: 'C027-01', name: 'Ayam Broiler', variety: 'Broiler', price: 33000, change: 2.5 },
                { id: 'C027-02', name: 'Ayam Kampung', variety: 'Kampung', price: 85000, change: 1.0 },
                { id: 'C027-03', name: 'Dada Ayam', variety: 'Breast', price: 45000, change: 1.8 }
            ]
        },
        {
            id: 'C028', name: 'Ikan Laut', icon: '🐟', category: 'Protein', unit: 'kg', avgPrice: 45000, change: -0.8,
            subCommodities: [
                { id: 'C028-01', name: 'Ikan Tongkol', variety: 'Tuna', price: 35000, change: -1.2 },
                { id: 'C028-02', name: 'Ikan Kakap', variety: 'Snapper', price: 75000, change: 0.5 },
                { id: 'C028-03', name: 'Ikan Salmon', variety: 'Salmon', price: 180000, change: 0.2 }
            ]
        },
        {
            id: 'C029', name: 'Udang', icon: '🦐', category: 'Protein', unit: 'kg', avgPrice: 95000, change: 1.2,
            subCommodities: [
                { id: 'C029-01', name: 'Udang Vaname', variety: 'Vaname', price: 85000, change: 1.5 },
                { id: 'C029-02', name: 'Udang Windu', variety: 'Tiger', price: 120000, change: 0.8 },
                { id: 'C029-03', name: 'Cumi-cumi', variety: 'Squid', price: 75000, change: 1.5 }
            ]
        },
        {
            id: 'C030', name: 'Susu', icon: '🥛', category: 'Protein', unit: 'liter', avgPrice: 18000, change: 0.5,
            subCommodities: [
                { id: 'C030-01', name: 'Susu Segar', variety: 'Fresh', price: 15000, change: 0.8 },
                { id: 'C030-02', name: 'Susu UHT', variety: 'UHT', price: 18000, change: 0.5 },
                { id: 'C030-03', name: 'Yogurt', variety: 'Yogurt', price: 25000, change: 0.6 }
            ]
        },
        // PERKEBUNAN
        {
            id: 'C031', name: 'Kopi', icon: '☕', category: 'Perkebunan', unit: 'kg', avgPrice: 85000, change: 2.5,
            subCommodities: [
                { id: 'C031-01', name: 'Kopi Arabika', variety: 'Arabica', price: 120000, change: 2.0 },
                { id: 'C031-02', name: 'Kopi Robusta', variety: 'Robusta', price: 65000, change: 3.0 },
                { id: 'C031-03', name: 'Kopi Luwak', variety: 'Luwak', price: 850000, change: 0.5 }
            ]
        },
        {
            id: 'C032', name: 'Kakao', icon: '🍫', category: 'Perkebunan', unit: 'kg', avgPrice: 45000, change: 5.8,
            subCommodities: [
                { id: 'C032-01', name: 'Biji Kakao Fermentasi', variety: 'Fermented', price: 48000, change: 6.0 },
                { id: 'C032-02', name: 'Kakao Bubuk', variety: 'Powder', price: 85000, change: 3.5 },
                { id: 'C032-03', name: 'Dark Chocolate', variety: 'Dark', price: 120000, change: 2.0 }
            ]
        },
        {
            id: 'C033', name: 'Teh', icon: '🍵', category: 'Perkebunan', unit: 'kg', avgPrice: 55000, change: 1.2,
            subCommodities: [
                { id: 'C033-01', name: 'Teh Hitam', variety: 'Black', price: 65000, change: 1.0 },
                { id: 'C033-02', name: 'Teh Hijau', variety: 'Green', price: 85000, change: 0.8 },
                { id: 'C033-03', name: 'Matcha', variety: 'Matcha', price: 350000, change: 0.3 }
            ]
        },
        {
            id: 'C034', name: 'Kelapa', icon: '🥥', category: 'Perkebunan', unit: 'butir', avgPrice: 8000, change: -1.5,
            subCommodities: [
                { id: 'C034-01', name: 'Kelapa Tua', variety: 'Mature', price: 8000, change: -1.8 },
                { id: 'C034-02', name: 'Kelapa Muda', variety: 'Young', price: 12000, change: -0.8 },
                { id: 'C034-03', name: 'VCO', variety: 'Virgin Oil', price: 120000, change: 0.2 }
            ]
        },
        {
            id: 'C035', name: 'Lada', icon: '🌶️', category: 'Bumbu', unit: 'kg', avgPrice: 95000, change: 3.2,
            subCommodities: [
                { id: 'C035-01', name: 'Lada Hitam', variety: 'Black', price: 95000, change: 3.5 },
                { id: 'C035-02', name: 'Lada Putih', variety: 'White', price: 120000, change: 2.8 },
                { id: 'C035-03', name: 'Lada Bubuk', variety: 'Powder', price: 110000, change: 2.5 }
            ]
        },
        {
            id: 'C036', name: 'Cengkeh', icon: '🌿', category: 'Perkebunan', unit: 'kg', avgPrice: 125000, change: 4.5,
            subCommodities: [
                { id: 'C036-01', name: 'Cengkeh Kering', variety: 'Dried', price: 125000, change: 4.8 },
                { id: 'C036-02', name: 'Minyak Cengkeh', variety: 'Oil', price: 280000, change: 2.5 },
                { id: 'C036-03', name: 'Cengkeh Bubuk', variety: 'Powder', price: 145000, change: 3.8 }
            ]
        },
        {
            id: 'C037', name: 'Pala', icon: '🌰', category: 'Perkebunan', unit: 'kg', avgPrice: 145000, change: 2.8,
            subCommodities: [
                { id: 'C037-01', name: 'Pala Utuh', variety: 'Whole', price: 145000, change: 3.0 },
                { id: 'C037-02', name: 'Pala Bubuk', variety: 'Powder', price: 165000, change: 2.5 },
                { id: 'C037-03', name: 'Minyak Pala', variety: 'Oil', price: 320000, change: 1.5 }
            ]
        },
        {
            id: 'C038', name: 'Karet', icon: '🌳', category: 'Perkebunan', unit: 'kg', avgPrice: 18000, change: -2.5,
            subCommodities: [
                { id: 'C038-01', name: 'Karet Sheet', variety: 'Sheet', price: 18000, change: -2.8 },
                { id: 'C038-02', name: 'Lateks', variety: 'Latex', price: 15000, change: -3.0 },
                { id: 'C038-03', name: 'Karet SIR 20', variety: 'SIR 20', price: 17500, change: -2.2 }
            ]
        },
        {
            id: 'C039', name: 'Sawit', icon: '🌴', category: 'Perkebunan', unit: 'kg', avgPrice: 2800, change: -1.8,
            subCommodities: [
                { id: 'C039-01', name: 'TBS Sawit', variety: 'FFB', price: 2800, change: -2.0 },
                { id: 'C039-02', name: 'CPO', variety: 'Crude Palm Oil', price: 14500, change: -1.5 },
                { id: 'C039-03', name: 'Olein', variety: 'Olein', price: 15500, change: -1.2 }
            ]
        },
        {
            id: 'C040', name: 'Jahe', icon: '🫚', category: 'Bumbu', unit: 'kg', avgPrice: 35000, change: 8.5,
            subCommodities: [
                { id: 'C040-01', name: 'Jahe Merah', variety: 'Red', price: 45000, change: 10.0 },
                { id: 'C040-02', name: 'Jahe Emprit', variety: 'Emprit', price: 38000, change: 8.5 },
                { id: 'C040-03', name: 'Kunyit', variety: 'Turmeric', price: 32000, change: 7.5 }
            ]
        }
    ],

    getAll() {
        return this.data;
    },

    getById(id) {
        return this.data.find(c => c.id === id);
    },

    getByCategory(category) {
        if (category === 'all') return this.data;
        return this.data.filter(c => c.category.toLowerCase() === category.toLowerCase());
    },

    search(query) {
        const q = query.toLowerCase();
        return this.data.filter(c =>
            c.name.toLowerCase().includes(q) ||
            c.category.toLowerCase().includes(q)
        );
    },

    getTopMovers(limit = 5) {
        return [...this.data]
            .sort((a, b) => Math.abs(b.change) - Math.abs(a.change))
            .slice(0, limit);
    },

    getPriceUp() {
        return this.data.filter(c => c.change > 0);
    },

    getPriceDown() {
        return this.data.filter(c => c.change < 0);
    }
};
