/**
 * Taniku - State Management Module
 * Handles loading states, sync status, and event emission
 */

const State = {
    // Current state
    _state: {
        isLoading: true,
        syncStatus: 'idle', // idle, loading, success, error
        lastSync: null,
        currentPage: 'dashboard',
        selectedCommodity: null,
        userLocation: null,
        theme: 'dark',
        searchQuery: '',
        filters: {
            category: 'all',
            sortBy: 'name'
        }
    },

    // Event listeners
    _listeners: {},

    // Get state
    get(key) {
        return key ? this._state[key] : { ...this._state };
    },

    // Set state
    set(key, value) {
        const oldValue = this._state[key];
        this._state[key] = value;
        this._emit('stateChange', { key, value, oldValue });
        this._emit(`${key}Changed`, { value, oldValue });
    },

    // Subscribe to events
    on(event, callback) {
        if (!this._listeners[event]) {
            this._listeners[event] = [];
        }
        this._listeners[event].push(callback);
        return () => this.off(event, callback);
    },

    // Unsubscribe
    off(event, callback) {
        if (this._listeners[event]) {
            this._listeners[event] = this._listeners[event].filter(cb => cb !== callback);
        }
    },

    // Emit event
    _emit(event, data) {
        if (this._listeners[event]) {
            this._listeners[event].forEach(cb => cb(data));
        }
    },

    // Loading management
    showLoading(message = 'Memuat...') {
        this.set('isLoading', true);
        const loadingScreen = document.getElementById('loading-screen');
        const loadingStatus = document.getElementById('loading-status');
        if (loadingScreen) loadingScreen.classList.remove('hidden');
        if (loadingStatus) loadingStatus.textContent = message;
    },

    hideLoading() {
        this.set('isLoading', false);
        const loadingScreen = document.getElementById('loading-screen');
        const app = document.getElementById('app');
        if (loadingScreen) loadingScreen.classList.add('hidden');
        if (app) app.classList.remove('hidden');
    },

    updateLoadingProgress(percent, message) {
        const progressBar = document.querySelector('.loading-progress-bar');
        const loadingStatus = document.getElementById('loading-status');
        if (progressBar) {
            progressBar.style.width = `${percent}%`;
            progressBar.style.animation = 'none';
        }
        if (loadingStatus && message) {
            loadingStatus.textContent = message;
        }
    },

    // Sync status management
    setSyncStatus(status, message) {
        this.set('syncStatus', status);
        const syncStatusEl = document.getElementById('sync-status');
        if (syncStatusEl) {
            syncStatusEl.className = `sync-status ${status}`;
            const iconMap = {
                idle: '✓',
                loading: '🔄',
                success: '✓',
                error: '⚠️',
                offline: '📴'
            };
            const textMap = {
                idle: 'Tersinkron',
                loading: 'Sinkronisasi...',
                success: 'Tersinkron',
                error: 'Gagal sinkron',
                offline: 'Offline'
            };
            syncStatusEl.querySelector('.sync-icon').textContent = iconMap[status] || '🔄';
            syncStatusEl.querySelector('.sync-text').textContent = message || textMap[status];
        }
        if (status === 'success') {
            this.set('lastSync', new Date().toISOString());
        }
    },

    // Page navigation
    navigateTo(page) {
        const oldPage = this._state.currentPage;
        if (oldPage === page) return;

        // Update nav items
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.page === page);
        });

        // Animate page transition
        const oldPageEl = document.getElementById(`page-${oldPage}`);
        const newPageEl = document.getElementById(`page-${page}`);

        if (oldPageEl) {
            oldPageEl.classList.add('exit');
            setTimeout(() => {
                oldPageEl.classList.remove('active', 'exit');
            }, 300);
        }

        if (newPageEl) {
            setTimeout(() => {
                newPageEl.classList.add('active');
            }, 150);
        }

        // Update title
        const titleMap = {
            dashboard: 'Dashboard',
            komoditas: 'Komoditas',
            peta: 'Peta Harga',
            internasional: 'Internasional',
            kalkulator: 'Kalkulator'
        };
        const pageTitle = document.getElementById('page-title');
        if (pageTitle) pageTitle.textContent = titleMap[page] || page;

        this.set('currentPage', page);
    },

    // Theme management
    toggleTheme() {
        const newTheme = this._state.theme === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('taniku-theme', newTheme);

        const themeIcon = document.querySelector('.theme-icon');
        if (themeIcon) {
            themeIcon.textContent = newTheme === 'dark' ? '🌙' : '☀️';
        }

        this.set('theme', newTheme);
    },

    loadTheme() {
        const savedTheme = localStorage.getItem('taniku-theme') || 'dark';
        document.documentElement.setAttribute('data-theme', savedTheme);
        this._state.theme = savedTheme;

        const themeIcon = document.querySelector('.theme-icon');
        if (themeIcon) {
            themeIcon.textContent = savedTheme === 'dark' ? '🌙' : '☀️';
        }
    },

    // Location display
    setLocation(location) {
        this.set('userLocation', location);
        const locationBadge = document.getElementById('location-badge');
        if (locationBadge && location) {
            locationBadge.querySelector('.location-text').textContent = location.city || location.region || 'Indonesia';
        }
    }
};

// Export
if (typeof module !== 'undefined' && module.exports) {
    module.exports = State;
}
