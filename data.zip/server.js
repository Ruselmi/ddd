const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// BPS API Proxy
const BPS_API_KEY = 'e11b132228efeb1fa7693a7dad9709ce';
const BPS_BASE_URL = 'https://webapi.bps.go.id/v1/api';

app.get('/api/bps/:endpoint(*)', async (req, res) => {
    try {
        const endpoint = req.params.endpoint;
        const queryParams = new URLSearchParams(req.query);
        queryParams.set('key', BPS_API_KEY);
        
        const url = `${BPS_BASE_URL}/${endpoint}?${queryParams}`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        res.json(data);
    } catch (error) {
        console.error('BPS API Error:', error);
        res.status(500).json({ error: 'Failed to fetch from BPS API' });
    }
});

// Exchange Rate API (mock for demo)
app.get('/api/exchange-rate', (req, res) => {
    res.json({
        USD_IDR: 15850,
        lastUpdate: new Date().toISOString()
    });
});

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Serve index.html for all other routes (SPA)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

app.listen(PORT, () => {
    console.log(`🌾 Taniku Server running at http://localhost:${PORT}`);
});
